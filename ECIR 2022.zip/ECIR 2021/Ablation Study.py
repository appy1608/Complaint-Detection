# -*- coding: utf-8 -*-

"""Make sure the libraries tensorflow-hub, emoji, and bert-for-tf2 are installed"""
"""This code will run on the latest version of tensorflow and python"""

# IMPORTS #
import bert, keras
import re, string, random, os, pickle, emoji, itertools, sys, codecs
import pandas as pd
import numpy as np
import tensorflow as tf
import tensorflow_hub as hub
from nltk import tokenize
from collections import defaultdict
from keras import backend as K
from keras.preprocessing.text import Tokenizer, text_to_word_sequence
from keras.preprocessing.sequence import pad_sequences
from keras.utils.np_utils import to_categorical
from keras.callbacks import ModelCheckpoint
from tensorflow.keras import initializers
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.layers import Layer, Input, InputSpec, Dense, Dropout, LSTM, Bidirectional, concatenate, Flatten, Average, Embedding, Lambda
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, classification_report, confusion_matrix, precision_recall_fscore_support
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import StratifiedKFold, train_test_split

np.random.seed(100)

# FUNCTION TO FLIP THE GRADIENT OF THE INCOMING LAYER #
@tf.custom_gradient
def grad_reverse(x):
    y = tf.identity(x)
    def custom_grad(dy):
        return -dy
    return y, custom_grad

class GradReverse(Layer):
    def __init__(self):
        super().__init__()

    def call(self, x):
        return grad_reverse(x)

# ATTENTION MECHANISM #
def attentionScoresIA(var):
  Q_t,K_t,V_t=var[0],var[1],var[2]
  scores = tf.matmul(Q_t, K_t, transpose_b=True)
  distribution = tf.nn.softmax(scores)
  scores=tf.matmul(distribution, V_t)
  return scores

module_url = 'https://tfhub.dev/tensorflow/bert_en_uncased_L-12_H-768_A-12/2'
bert_layer = hub.KerasLayer(module_url, trainable = False)
vocab_file = bert_layer.resolved_object.vocab_file.asset_path.numpy()
do_lower_case = bert_layer.resolved_object.do_lower_case.numpy()
tokenizer1 = bert.bert_tokenization.FullTokenizer(vocab_file, do_lower_case)

def bert_encode(texts, tokenizer, max_len):
    all_tokens = []
    all_masks = []
    all_segments = []
    for text in texts:
        text = tokenizer.tokenize(text)
        text = text[:max_len-2]
        input_sequence = ["[CLS]"] + text + ["[SEP]"]
        pad_len = max_len - len(input_sequence)
        tokens = tokenizer.convert_tokens_to_ids(input_sequence) + [0] * pad_len
        pad_masks = [1] * len(input_sequence) + [0] * pad_len
        segment_ids = [0] * max_len
        all_tokens.append(tokens)
        all_masks.append(pad_masks)
        all_segments.append(segment_ids)
    return np.array(all_tokens), np.array(all_masks), np.array(all_segments)

MAX_SENT_LENGTH = 512

data_train = pd.read_csv('Complaint data annotation.csv')
data_train = data_train.drop(['id', 'Remarks (if any)', 'domain'], axis=1)
data_train = data_train.sample(n=3448)
data_train = data_train.reset_index(drop=True)
print('\nComplaint Dataset Shape:', data_train.shape)

data_sarcasm = pd.read_csv('sarcasm.csv')
data_sarcasm = data_sarcasm.dropna()
print('\nSarcasm Dataset Shape before: ', data_sarcasm.shape)

# CREATING A BALANCED SARCASM DATASET WHICH HAS A TOTAL OF 3448 ROWS #
data_sarc = data_sarcasm[data_sarcasm['label']==1]
data_nonsarc = data_sarcasm[data_sarcasm['label']==0]
data_sarc = data_sarc.sample(n=1724)
data_nonsarc = data_nonsarc.sample(n=1724)
sarcasm_data = [data_sarc, data_nonsarc]
data_sarcasm = pd.concat(sarcasm_data)
data_sarcasm = data_sarcasm.sample(frac=1)
data_sarcasm = data_sarcasm.reset_index(drop=True)
print('\nSarcasm Data Shape after:', data_sarcasm.shape)

# TWEET CLEANING #

def load_dict_smileys():
  return {":?)":"happy", ":)":"happy", ":-]":"happy", ":]":"happy", ":-3":"happy", ":3":"happy", ":->":"happy", ":>":"happy", "8-)":"happy", "8)":"happy", ":-}":"happy", ":}":"happy", ":o)":"happy", ":c)":"happy", ":^)":"happy", "=]":"happy", "=)":"happy", ":-))":"very happy", ":?D":"laughing", ":D":"laughing", "8?D":"laughing", "8D":"laughing", "x?D":"laughing", "xD":"laughing", "X?D":"laughing", "XD":"laughing", "=D":"laughing", "=3":"laughing", "B^D":"laughing", ":?(":"sad", ":(":"sad", ":?c":"sad", ":c":"sad", ":?<":"sad", ":<":"sad", ":?[":"sad", ":[":"sad", ":-||":"sad", ">:[":"sad", ":{":"sad", ":@":"sad", ">:(":"sad", ":'?(":"crying", ":'(":"crying", ":'?)":"happy", ":')":"happy", "D?':":"disgust", "D:<":"disgust", "D:":"disgust", "D8":"disgust", "D;":"disgust", "D=":"disgust", "DX":"disgust", ":?O":"surprise", ":O":"surprise", ":?o":"surprise", ":o":"surprise", ":-0":"surprise", "8?0":"surprise", ">:O":"surprise", ":-*":"kiss", ":*":"kiss", ":×":"kiss", ";?)":"wink", ";)":"wink", "*-)":"wink", "*)":"wink", ";?]":"wink", ";]":"wink", ";^)":"wink", ":?,":"wink", ";D":"wink", ":?P":"cheeky", ":P":"cheeky", "X?P":"cheeky", "XP":"cheeky", "x?p":"cheeky", "xp":"cheeky", ":?p":"cheeky", ":p":"cheeky", ":?Þ":"cheeky", ":Þ":"cheeky", ":?þ":"cheeky", ":þ":"cheeky", ":?b":"cheeky", ":b":"cheeky", "d:":"cheeky","=p":"cheeky",">:P":"cheeky", ":?/":"annoyed", ":/":"annoyed", ":?.":"annoyed",  ">:/":"annoyed", "=/":"annoyed", ":L":"annoyed", "=L":"annoyed", ":S":"annoyed"}

def load_dict_contractions():
  return {"ain't":"is not", "amn't":"am not", "aren't":"are not", "can't":"cannot", "'cause":"because", "couldn't":"could not", "couldn't've":"could not have", "could've":"could have", "daren't":"dare not", "daresn't":"dare not", "dasn't":"dare not", "didn't":"did not", "doesn't":"does not", "don't":"do not", "e'er":"ever", "em":"them", "everyone's":"everyone is", "finna":"fixing to", "gimme":"give me", "gonna":"going to", "gon't":"go not", "gotta":"got to", "hadn't":"had not", "hasn't":"has not", "haven't":"have not", "he'd":"he would", "he'll":"he will", "he's":"he is", "he've":"he have", "how'd":"how would", "how'll":"how will", "how're":"how are", "how's":"how is", "i'd":"i would", "i'll":"i will", "i'm":"i am", "i'm'a":"i am about to", "i'm'o":"i am going to", "isn't":"is not", "it'd":"it would", "it'll":"it will", "it's":"it is", "i've":"i have", "kinda":"kind of", "let's":"let us", "mayn't":"may not", "may've":"may have", "mightn't":"might not", "might've":"might have", "mustn't":"must not", "mustn't've":"must not have", "must've":"must have", "needn't":"need not", "ne'er":"never", "o'":"of", "o'er":"over", "ol'":"old", "oughtn't":"ought not", "shalln't":"shall not", "shan't":"shall not", "she'd":"she would", "she'll":"she will", "she's":"she is", "shouldn't":"should not", "shouldn't've":"should not have", "should've":"should havite", "somebody's":"somebody is", "someone's":"someone is", "something's":"something is", "that'd":"that would", "that'll":"that will", "that're":"that are", "that's":"that is", "there'd":"there would", "there'll":"there will", "there're":"there are", "there's":"there is", "these're":"these are", "they'd":"they would", "they'll":"they will", "they're":"they are", "they've":"they have", "this's":"this is", "those're":"those are", "'tis":"it is", "'twas":"it was", "wanna":"want to", "wasn't":"was not", "we'd":"we would", "we'd've":"we would have", "we'll":"we will", "we're":"we are", "weren't":"were not", "we've":"we have", "what'd":"what did", "what'll":"what will", "what're":"what are", "what's":"what is", "what've":"what have", "when's":"when is", "where'd":"where did", "where're":"where are", "where's":"where is", "where've":"where have", "which's":"which is", "who'd":"who would", "who'd've":"who would have", "who'll":"who will", "who're":"who are", "who's":"who is", "who've":"who have", "why'd":"why did", "why're":"why are", "why's":"why is", "won't":"will not", "wouldn't":"would not", "would've":"would have", "y'all":"you all", "you'd":"you would", "you'll":"you will", "you're":"you are", "you've":"you have", "whatcha":"what are you", "luv":"love", "sux":"sucks"}
        
def reduce_lengthening(text):
    pattern = re.compile(r"(.)\1{2,}")
    return pattern.sub(r"\1\1", text)

def clean_str(string):
    pattern = r'(?:\@|https?\://)\S+' 
    string = string.replace("â€™", "'")
    string = string.replace("&amp;", "and")
    string = string.replace('\n', ' ').replace('\t', ' ')
    string = string.lower()
    string = reduce_lengthening(string)
    CONTRACTIONS = load_dict_contractions()
    words = string.split()
    reformed = [CONTRACTIONS[word] if word in CONTRACTIONS else word for word in words]
    string = " ".join(reformed)
    SMILEY = load_dict_smileys()  
    words = string.split()
    reformed = [SMILEY[word] if word in SMILEY else word for word in words]
    string = " ".join(reformed)
    string = emoji.demojize(string)
    string = ' '.join(string.split())
    string = re.sub(pattern, '', string)
    string = re.sub(r'pic.twitter.com/[\w]*',"", string)
    string = re.sub('[^A-Za-z0-9.?;!]+', ' ', string).lstrip().lower()
    string = string.replace(";"," ; ").replace("."," . ").replace("?"," ? ").replace("!"," ! ")
    string = ' '.join(string.split())
    string = string.replace('trade mark', '')
    return string.strip().lower()

data_train['tweet'] = data_train['tweet'].apply(clean_str)
data_sarcasm['tweet'] = data_sarcasm['tweet'].apply(clean_str)

# CREATING A TRAIN-TEST-VALIDATION SPLIT #
X_train_complaint, X_test_complaint, Y_train_complaint, Y_test_complaint = train_test_split(data_train, data_train.label, stratify=data_train.label, test_size=0.15, random_state=0)
X_train_complaint, X_val_complaint, Y_train_complaint, Y_val_complaint = train_test_split(X_train_complaint, Y_train_complaint, stratify=Y_train_complaint, test_size=0.10, random_state=0)

X_train_emotion, X_test_emotion, Y_train_emotion, Y_test_emotion = train_test_split(data_train, data_train.emotion, stratify=data_train.emotion, test_size=0.15, random_state=0)
X_train_emotion, X_val_emotion, Y_train_emotion, Y_val_emotion = train_test_split(X_train_emotion, Y_train_emotion, stratify=Y_train_emotion, test_size=0.10, random_state=0)

X_train_sentiment, X_test_sentiment, Y_train_sentiment, Y_test_sentiment = train_test_split(data_train, data_train.sentiment, stratify=data_train.sentiment, test_size=0.15, random_state=0)
X_train_sentiment, X_val_sentiment, Y_train_sentiment, Y_val_sentiment = train_test_split(X_train_sentiment, Y_train_sentiment, stratify=Y_train_sentiment, test_size=0.10, random_state=0)

X_train_sarcasm, X_test_sarcasm, Y_train_sarcasm, Y_test_sarcasm = train_test_split(data_sarcasm, data_sarcasm.label, stratify = data_sarcasm.label, test_size=0.15, random_state=0)
X_train_sarcasm, X_val_sarcasm, Y_train_sarcasm, Y_val_sarcasm = train_test_split(X_train_sarcasm, Y_train_sarcasm, stratify=Y_train_sarcasm, test_size=0.10, random_state=0)

X_train_complaint = X_train_complaint.reset_index(drop=True)
X_val_complaint = X_val_complaint.reset_index(drop=True)
X_test_complaint = X_test_complaint.reset_index(drop=True)

X_train_emotion = X_train_emotion.reset_index(drop=True)
X_val_emotion = X_val_emotion.reset_index(drop=True)
X_test_emotion = X_test_emotion.reset_index(drop=True)

X_train_sentiment = X_train_sentiment.reset_index(drop=True)
X_val_sentiment = X_val_sentiment.reset_index(drop=True)
X_test_sentiment = X_test_sentiment.reset_index(drop=True)

X_train_sarcasm = X_train_sarcasm.reset_index(drop=True)
X_test_sarcasm = X_test_sarcasm.reset_index(drop=True)
X_val_sarcasm = X_val_sarcasm.reset_index(drop=True)

complaint_labels_train = []
complaint_labels_test = []
complaint_labels_val = []
emotion_labels_train = []
emotion_labels_test = []
emotion_labels_val = []
sentiment_labels_train = []
sentiment_labels_test = []
sentiment_labels_val = []
sarcasm_labels_train = []
sarcasm_labels_val = []
sarcasm_labels_test = []

texts_train = []
texts_test = []
texts_val = []
emotion_texts_train = []
emotion_texts_val = []
emotion_texts_test = []
sentiment_texts_train = []
sentiment_texts_val = []
sentiment_texts_test = []
sarcasm_texts_train = []
sarcasm_texts_val = []
sarcasm_texts_test = []

for idx in range(X_train_complaint.shape[0]):
    text = X_train_complaint.tweet[idx]
    texts_train.append(text)
    complaint_labels_train.append(X_train_complaint.label[idx])

for idx in range(X_test_complaint.shape[0]):
    text = X_test_complaint.tweet[idx]
    texts_test.append(text)
    complaint_labels_test.append(X_test_complaint.label[idx])    

for idx in range(X_val_complaint.shape[0]):
    text = X_val_complaint.tweet[idx]
    texts_val.append(text)
    complaint_labels_val.append(X_val_complaint.label[idx])    

for idx in range(X_train_emotion.shape[0]):
    text = X_train_emotion.tweet[idx]
    emotion_texts_train.append(text)
    emotion_labels_train.append(X_train_emotion.emotion[idx])

for idx in range(X_test_emotion.shape[0]):
    text = X_test_emotion.tweet[idx]
    emotion_texts_test.append(text)
    emotion_labels_test.append(X_test_emotion.emotion[idx])    

for idx in range(X_val_emotion.shape[0]):
    text = X_val_emotion.tweet[idx]
    emotion_texts_val.append(text)
    emotion_labels_val.append(X_val_emotion.emotion[idx])    

for idx in range(X_train_sentiment.shape[0]):
    text = X_train_sentiment.tweet[idx]
    sentiment_texts_train.append(text)
    sentiment_labels_train.append(X_train_sentiment.sentiment[idx])

for idx in range(X_val_sentiment.shape[0]):
    text = X_val_sentiment.tweet[idx]
    sentiment_texts_val.append(text)
    sentiment_labels_val.append(X_val_sentiment.sentiment[idx])

for idx in range(X_test_sentiment.shape[0]):
    text = X_test_sentiment.tweet[idx]
    sentiment_texts_test.append(text)
    sentiment_labels_test.append(X_test_sentiment.sentiment[idx])        

for idx in range(X_train_sarcasm.shape[0]):
    text = X_train_sarcasm.tweet[idx]
    sarcasm_texts_train.append(text)
    sarcasm_labels_train.append(X_train_sarcasm.label[idx])

for idx in range(X_val_sarcasm.shape[0]):
    text = X_val_sarcasm.tweet[idx]
    sarcasm_texts_val.append(text)
    sarcasm_labels_val.append(X_val_sarcasm.label[idx])

for idx in range(X_test_sarcasm.shape[0]):
    text = X_test_sarcasm.tweet[idx]
    sarcasm_texts_test.append(text)
    sarcasm_labels_test.append(X_test_sarcasm.label[idx])

# Generating BERT encodings #
data_train = bert_encode(texts_train, tokenizer1, max_len=MAX_SENT_LENGTH)
data_test = bert_encode(texts_test, tokenizer1, max_len=MAX_SENT_LENGTH)
data_val = bert_encode(texts_val, tokenizer1, max_len=MAX_SENT_LENGTH)

data_sentiment_train = bert_encode(sentiment_texts_train, tokenizer1, max_len=MAX_SENT_LENGTH)
data_sentiment_test = bert_encode(sentiment_texts_test, tokenizer1, max_len=MAX_SENT_LENGTH)
data_sentiment_val = bert_encode(sentiment_texts_val, tokenizer1, max_len=MAX_SENT_LENGTH)

data_emotion_train = bert_encode(emotion_texts_train, tokenizer1, max_len=MAX_SENT_LENGTH)
data_emotion_test = bert_encode(emotion_texts_test, tokenizer1, max_len=MAX_SENT_LENGTH)
data_emotion_val = bert_encode(emotion_texts_val, tokenizer1, max_len=MAX_SENT_LENGTH)

data_sarcasm_train = bert_encode(sarcasm_texts_train, tokenizer1, max_len=MAX_SENT_LENGTH)
data_sarcasm_test = bert_encode(sarcasm_texts_test, tokenizer1, max_len=MAX_SENT_LENGTH)
data_sarcasm_val = bert_encode(sarcasm_texts_val, tokenizer1, max_len=MAX_SENT_LENGTH)

le = LabelEncoder()
complaint_labels_temp_train = le.fit_transform(complaint_labels_train)
complaint_labels_temp_test = le.fit_transform(complaint_labels_test)
complaint_labels_temp_val = le.fit_transform(complaint_labels_val)

emotion_labels_temp_train = le.fit_transform(emotion_labels_train)
emotion_labels_temp_test = le.fit_transform(emotion_labels_test)
emotion_labels_temp_val = le.fit_transform(emotion_labels_val)

sentiment_labels_temp_train = le.fit_transform(sentiment_labels_train)
sentiment_labels_temp_test = le.fit_transform(sentiment_labels_test)
sentiment_labels_temp_val = le.fit_transform(sentiment_labels_val)

sarcasm_labels_temp_train = le.fit_transform(sarcasm_labels_train)
sarcasm_labels_temp_test = le.fit_transform(sarcasm_labels_test)
sarcasm_labels_temp_val = le.fit_transform(sarcasm_labels_val)

complaint_labels_train = to_categorical(np.asarray(complaint_labels_temp_train))
complaint_labels_test = to_categorical(np.asarray(complaint_labels_temp_test))
complaint_labels_val = to_categorical(np.asarray(complaint_labels_temp_val))

emotion_labels_train = to_categorical(np.asarray(emotion_labels_temp_train))
emotion_labels_test = to_categorical(np.asarray(emotion_labels_temp_test))
emotion_labels_val = to_categorical(np.asarray(emotion_labels_temp_val))

sentiment_labels_train = to_categorical(np.asarray(sentiment_labels_temp_train))
sentiment_labels_test = to_categorical(np.asarray(sentiment_labels_temp_test))
sentiment_labels_val = to_categorical(np.asarray(sentiment_labels_temp_val))

sarcasm_labels_train = to_categorical(np.asarray(sarcasm_labels_temp_train))
sarcasm_labels_test = to_categorical(np.asarray(sarcasm_labels_temp_test))
sarcasm_labels_val = to_categorical(np.asarray(sarcasm_labels_temp_val))

"""*****************************************************************************************************************************"""

# TRAINING COMPLAINT AND SENTIMENT #

"""The private layers"""
input_word_ids1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output1, sequence_output1 = bert_layer([input_word_ids1, input_mask1, segment_ids1])
gru = Bidirectional(GRU(256, name = 'gru_input_1', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output1)
input1_final = Dense(100, activation = "relu")(gru)
Q_t= Dense(100, activation="relu")(input1_final)
K_t= Dense(100, activation="relu")(input1_final)
V_t= Dense(100, activation="relu")(input1_final)
C1 = Lambda(attentionScoresIA)([Q_t,K_t,V_t])
C1_flatten = Flatten()(C1)
complaint_specific_output = Dense(2, activation = "softmax", name = "complaint_specific_output")(C1_flatten)

input_word_ids2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output2, sequence_output2 = bert_layer([input_word_ids2, input_mask2, segment_ids2])
gru2 = Bidirectional(GRU(256, name = 'gru_input_2', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output2)
input2_final = Dense(100, activation = "relu")(gru2)
Q_t2 = Dense(100, activation="relu")(input2_final)
K_t2 = Dense(100, activation="relu")(input2_final)
V_t2 = Dense(100, activation="relu")(input2_final)
C2 = Lambda(attentionScoresIA)([Q_t2,K_t2,V_t2])
C2_flatten = Flatten()(C2)
sentiment_specific_output = Dense(3, activation = "softmax", name = "sentiment_specific_output")(C2_flatten)

"""The shared layer"""
M = Average()([C1, C2])
shared_output = Dense(100, activation = "relu", name = "shared_layer")(M)
shared_output = Flatten()(shared_output)
complaint_shared_output = Dense(2, activation = "softmax", name = "task_shared_complaint")(shared_output)
sentiment_shared_output = Dense(3, activation = "softmax", name = "task_shared_sentiment")(shared_output)

"""Adversarial component"""
adv_complaint = GradReverse()(complaint_shared_output)
adv_sentiment = GradReverse()(sentiment_shared_output)
complaint_adv_output = Dense(2, activation="softmax", name = "task_adv_complaint")(concatenate([complaint_shared_output, adv_complaint, complaint_specific_output]))
complaint_adv_output = 1 - complaint_adv_output
sentiment_adv_output = Dense(3, activation = "softmax", name = "task_adv_sentiment")(concatenate([sentiment_shared_output, adv_sentiment, sentiment_specific_output]))
sentiment_adv_output = 1 - sentiment_adv_output

"""Final Output Layers"""
out_complaint = Average(name='out_complaint')([complaint_specific_output, complaint_shared_output, complaint_adv_output])
out_sentiment = Average(name='out_sentiment')([sentiment_specific_output, sentiment_shared_output, sentiment_adv_output])

model = Model([[input_word_ids1, input_mask1, segment_ids1],[input_word_ids2, input_mask2, segment_ids2]],
              [out_complaint, out_sentiment])

model.compile(optimizer = Adam(0.0001), loss = {'out_complaint':'categorical_crossentropy', 'out_sentiment':'categorical_crossentropy'}, 
              loss_weights = [1, 0.5], metrics=['accuracy'])    

earlystopping = EarlyStopping(monitor='val_out_complaint_accuracy', patience=5, verbose=1, restore_best_weights=True)

model.fit([data_train, data_sentiment_train], [complaint_labels_train, sentiment_labels_train], 
          validation_data = ([data_val, data_sentiment_val], [complaint_labels_val, sentiment_labels_val]), 
          batch_size = 16, shuffle=True, verbose=1, epochs = 30, callbacks=earlystopping)

# Generating Predictions #
predicted = model.predict([data_test, data_sentiment_test])
# Complaint Results #
a = predicted[0]
pred_test1 = np.argmax(a, axis=1)
classes_test1 = np.argmax(to_categorical(complaint_labels_test), axis=1)[:,1]
predictions_test1=np.array(list(pred_test1))
print(classification_report(classes_test1, predictions_test1))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test1, predictions_test1, average='macro'))
cm1 = confusion_matrix(classes_test1, predictions_test1)
print('\nConfusion matrix:\n', cm1)
print('\nAccuracy:\n',accuracy_score(classes_test1, predictions_test1))
# Sentiment Results #
b = predicted[1]
pred_test2 = np.argmax(b, axis=1)
classes_test2 = np.argmax(to_categorical(sentiment_labels_test), axis=1)[:,1]
predictions_test2 = np.array(list(pred_test2))
print(classification_report(classes_test2, predictions_test2))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test2, predictions_test2, average='macro'))
cm2 = confusion_matrix(classes_test2, predictions_test2)
print('\nConfusion matrix:\n', cm2)
print('\nAccuracy:\n',accuracy_score(classes_test2, predictions_test2))

file_name = 'Complaint and Sentiment.txt'
with open(file_name, 'w') as file:
    print('Complaint Metrics\n', file=file)
    print(classification_report(classes_test1, predictions_test1), file = file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test1, predictions_test1, average='macro'), file = file)
    print('\nConfusion matrix:\n', cm1, file = file)
    print('\nAccuracy:\n',accuracy_score(classes_test1, predictions_test1), file = file)

    print('\nSentiment Metrics\n', file=file)
    print(classification_report(classes_test2, predictions_test2), file=file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test2, predictions_test2, average='macro'), file=file)
    print('\nConfusion matrix:\n', cm2, file=file)
    print('\nAccuracy:\n',accuracy_score(classes_test2, predictions_test2), file=file)


"""*****************************************************************************************************************************"""

# TRAINING COMPLAINT AND EMOTION #

"""The private layers"""
input_word_ids1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output1, sequence_output1 = bert_layer([input_word_ids1, input_mask1, segment_ids1])
gru = Bidirectional(GRU(256, name = 'gru_input_1', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output1)
input1_final = Dense(100, activation = "relu")(gru)
Q_t= Dense(100, activation="relu")(input1_final)
K_t= Dense(100, activation="relu")(input1_final)
V_t= Dense(100, activation="relu")(input1_final)
C1 = Lambda(attentionScoresIA)([Q_t,K_t,V_t])
C1_flatten = Flatten()(C1)
complaint_specific_output = Dense(2, activation = "softmax", name = "complaint_specific_output")(C1_flatten)

input_word_ids2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output2, sequence_output2 = bert_layer([input_word_ids2, input_mask2, segment_ids2])
gru2 = Bidirectional(GRU(256, name = 'gru_input_2', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output2)
input2_final = Dense(100, activation = "relu")(gru2)
Q_t2 = Dense(100, activation="relu")(input2_final)
K_t2 = Dense(100, activation="relu")(input2_final)
V_t2 = Dense(100, activation="relu")(input2_final)
C2 = Lambda(attentionScoresIA)([Q_t2,K_t2,V_t2])
C2_flatten = Flatten()(C2)
emotion_specific_output = Dense(6, activation = "softmax", name = "emotion_specific_output")(C2_flatten)

"""The shared layer"""
M = Average()([C1, C2])
shared_output = Dense(100, activation = "relu", name = "shared_layer")(M)
shared_output = Flatten()(shared_output)
complaint_shared_output = Dense(2, activation = "softmax", name = "task_shared_complaint")(shared_output)
emotion_shared_output = Dense(6, activation = "softmax", name = "task_shared_emotion")(shared_output)

"""Adversarial component"""
adv_complaint = GradReverse()(complaint_shared_output)
adv_emotion = GradReverse()(emotion_shared_output)
complaint_adv_output = Dense(2, activation="softmax", name = "task_adv_complaint")(concatenate([complaint_shared_output, adv_complaint, complaint_specific_output]))
complaint_adv_output = 1 - complaint_adv_output
emotion_adv_output = Dense(6, activation = "softmax", name = "task_adv_emotion")(concatenate([emotion_shared_output, adv_emotion, emotion_specific_output]))
emotion_adv_output = 1 - emotion_adv_output

"""Final Output Layers"""
out_complaint = Average(name='out_complaint')([complaint_specific_output, complaint_shared_output, complaint_adv_output])
out_emotion = Average(name='out_emotion')([emotion_specific_output, emotion_shared_output, emotion_adv_output])

model = Model([[input_word_ids1, input_mask1, segment_ids1],[input_word_ids2, input_mask2, segment_ids2]],
              [out_complaint, out_emotion])

model.compile(optimizer = Adam(0.0001), loss = {'out_complaint':'categorical_crossentropy', 'out_emotion':'categorical_crossentropy'}, 
              loss_weights = [1, 0.5], metrics=['accuracy'])    

earlystopping = EarlyStopping(monitor='val_out_complaint_accuracy', patience=5, verbose=1, restore_best_weights=True)

model.fit([data_train, data_emotion_train], [complaint_labels_train, emotion_labels_train], 
          validation_data = ([data_val, data_emotion_val], [complaint_labels_val, emotion_labels_val]), 
          batch_size = 16, shuffle=True, verbose=1, epochs = 30, callbacks=earlystopping)

# Generating Predictions #
predicted = model.predict([data_test, data_emotion_test])
# Complaint Results #
a = predicted[0]
pred_test1 = np.argmax(a, axis=1)
classes_test1 = np.argmax(to_categorical(complaint_labels_test), axis=1)[:,1]
predictions_test1=np.array(list(pred_test1))
print(classification_report(classes_test1, predictions_test1))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test1, predictions_test1, average='macro'))
cm1 = confusion_matrix(classes_test1, predictions_test1)
print('\nConfusion matrix:\n', cm1)
print('\nAccuracy:\n',accuracy_score(classes_test1, predictions_test1))
# Emotion Results #
b = predicted[1]
pred_test2 = np.argmax(b, axis=1)
classes_test2 = np.argmax(to_categorical(emotion_labels_test), axis=1)[:,1]
predictions_test2 = np.array(list(pred_test2))
print(classification_report(classes_test2, predictions_test2))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test2, predictions_test2, average='macro'))
cm2 = confusion_matrix(classes_test2, predictions_test2)
print('\nConfusion matrix:\n', cm2)
print('\nAccuracy:\n',accuracy_score(classes_test2, predictions_test2))

file_name = 'Complaint and Emotion.txt'
with open(file_name, 'w') as file:
    print('Complaint Metrics\n', file=file)
    print(classification_report(classes_test1, predictions_test1), file = file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test1, predictions_test1, average='macro'), file = file)
    print('\nConfusion matrix:\n', cm1, file = file)
    print('\nAccuracy:\n',accuracy_score(classes_test1, predictions_test1), file = file)

    print('\nEmotion Metrics\n', file=file)
    print(classification_report(classes_test2, predictions_test2), file=file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test2, predictions_test2, average='macro'), file=file)
    print('\nConfusion matrix:\n', cm2, file=file)
    print('\nAccuracy:\n',accuracy_score(classes_test2, predictions_test2), file=file)


"""*****************************************************************************************************************************"""

# TRAINING COMPLAINT AND SARCASM #

"""The private layers"""
input_word_ids1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output1, sequence_output1 = bert_layer([input_word_ids1, input_mask1, segment_ids1])
gru = Bidirectional(GRU(256, name = 'gru_input_1', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output1)
input1_final = Dense(100, activation = "relu")(gru)
Q_t= Dense(100, activation="relu")(input1_final)
K_t= Dense(100, activation="relu")(input1_final)
V_t= Dense(100, activation="relu")(input1_final)
C1 = Lambda(attentionScoresIA)([Q_t,K_t,V_t])
C1_flatten = Flatten()(C1)
complaint_specific_output = Dense(2, activation = "softmax", name = "complaint_specific_output")(C1_flatten)

input_word_ids2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output2, sequence_output2 = bert_layer([input_word_ids2, input_mask2, segment_ids2])
gru2 = Bidirectional(GRU(256, name = 'gru_input_2', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output2)
input2_final = Dense(100, activation = "relu")(gru2)
Q_t2 = Dense(100, activation="relu")(input2_final)
K_t2 = Dense(100, activation="relu")(input2_final)
V_t2 = Dense(100, activation="relu")(input2_final)
C2 = Lambda(attentionScoresIA)([Q_t2,K_t2,V_t2])
C2_flatten = Flatten()(C2)
sarcasm_specific_output = Dense(2, activation = "softmax", name = "sarcasm_specific_output")(C2_flatten)

"""The shared layer"""
M = Average()([C1, C2])
shared_output = Dense(100, activation = "relu", name = "shared_layer")(M)
shared_output = Flatten()(shared_output)
complaint_shared_output = Dense(2, activation = "softmax", name = "task_shared_complaint")(shared_output)
sarcasm_shared_output = Dense(2, activation = "softmax", name = "task_shared_sarcasm")(shared_output)

"""Adversarial component"""
adv_complaint = GradReverse()(complaint_shared_output)
adv_sarcasm = GradReverse()(sarcasm_shared_output)
complaint_adv_output = Dense(2, activation="softmax", name = "task_adv_complaint")(concatenate([complaint_shared_output, adv_complaint, complaint_specific_output]))
complaint_adv_output = 1 - complaint_adv_output
sarcasm_adv_output = Dense(2, activation = "softmax", name = "task_adv_sarcasm")(concatenate([sarcasm_shared_output, adv_sarcasm, sarcasm_specific_output]))
sarcasm_adv_output = 1 - sarcasm_adv_output

"""Final Output Layers"""
out_complaint = Average(name='out_complaint')([complaint_specific_output, complaint_shared_output, complaint_adv_output])
out_sarcasm = Average(name='out_sarcasm')([sarcasm_specific_output, sarcasm_shared_output, sarcasm_adv_output])

model = Model([[input_word_ids1, input_mask1, segment_ids1],[input_word_ids2, input_mask2, segment_ids2]],
              [out_complaint, out_sarcasm])

model.compile(optimizer = Adam(0.0001), loss = {'out_complaint':'categorical_crossentropy', 'out_sarcasm':'categorical_crossentropy'}, 
              loss_weights = [1, 0.5], metrics=['accuracy'])    

earlystopping = EarlyStopping(monitor='val_out_complaint_accuracy', patience=10, verbose=1, restore_best_weights=True)

model.fit([data_train, data_sarcasm_train], [complaint_labels_train, sarcasm_labels_train], 
          validation_data = ([data_val, data_sarcasm_val], [complaint_labels_val, sarcasm_labels_val]), 
          batch_size = 16, shuffle=True, verbose=1, epochs = 30, callbacks=earlystopping)

# Generating Predictions #
predicted = model.predict([data_test, data_sarcasm_test])
# Complaint Results #
a = predicted[0]
pred_test1 = np.argmax(a, axis=1)
classes_test1 = np.argmax(to_categorical(complaint_labels_test), axis=1)[:,1]
predictions_test1=np.array(list(pred_test1))
print(classification_report(classes_test1, predictions_test1))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test1, predictions_test1, average='macro'))
cm1 = confusion_matrix(classes_test1, predictions_test1)
print('\nConfusion matrix:\n', cm1)
print('\nAccuracy:\n',accuracy_score(classes_test1, predictions_test1))
# Sarcasm Results #
b = predicted[1]
pred_test2 = np.argmax(b, axis=1)
classes_test2 = np.argmax(to_categorical(sarcasm_labels_test), axis=1)[:,1]
predictions_test2 = np.array(list(pred_test2))
print(classification_report(classes_test2, predictions_test2))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test2, predictions_test2, average='macro'))
cm2 = confusion_matrix(classes_test2, predictions_test2)
print('\nConfusion matrix:\n', cm2)
print('\nAccuracy:\n',accuracy_score(classes_test2, predictions_test2))

file_name = 'Complaint and Sarcasm.txt'
with open(file_name, 'w') as file:
    print('Complaint Metrics\n', file=file)
    print(classification_report(classes_test1, predictions_test1), file = file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test1, predictions_test1, average='macro'), file = file)
    print('\nConfusion matrix:\n', cm1, file = file)
    print('\nAccuracy:\n',accuracy_score(classes_test1, predictions_test1), file = file)

    print('\nSarcasm Metrics\n', file=file)
    print(classification_report(classes_test2, predictions_test2), file=file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test2, predictions_test2, average='macro'), file=file)
    print('\nConfusion matrix:\n', cm2, file=file)
    print('\nAccuracy:\n',accuracy_score(classes_test2, predictions_test2), file=file)


"""*****************************************************************************************************************************"""


# TRAINING COMPLAINT, EMOTION, AND SENTIMENT #

"""The private layers"""
input_word_ids1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output1, sequence_output1 = bert_layer([input_word_ids1, input_mask1, segment_ids1])
gru = Bidirectional(GRU(256, name = 'gru_input_1', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output1)
input1_final = Dense(100, activation = "relu")(gru)
Q_t= Dense(100, activation="relu")(input1_final)
K_t= Dense(100, activation="relu")(input1_final)
V_t= Dense(100, activation="relu")(input1_final)
C1 = Lambda(attentionScoresIA)([Q_t,K_t,V_t])
C1_flatten = Flatten()(C1)
complaint_specific_output = Dense(2, activation = "softmax", name = "complaint_specific_output")(C1_flatten)

input_word_ids2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output2, sequence_output2 = bert_layer([input_word_ids2, input_mask2, segment_ids2])
gru2 = Bidirectional(GRU(256, name = 'gru_input_2', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output2)
input2_final = Dense(100, activation = "relu")(gru2)
Q_t2= Dense(100, activation="relu")(input2_final)
K_t2= Dense(100, activation="relu")(input2_final)
V_t2= Dense(100, activation="relu")(input2_final)
C2 = Lambda(attentionScoresIA)([Q_t2,K_t2,V_t2])
C2_flatten = Flatten()(C2)
sentiment_specific_output = Dense(3, activation = "softmax", name = "sentiment_specific_output")(C2_flatten)

input_word_ids3 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask3 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids3 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output3, sequence_output3 = bert_layer([input_word_ids3, input_mask3, segment_ids3])
gru3 = Bidirectional(GRU(256, name = 'gru_input_3', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output3)
input3_final = Dense(100, activation = "relu")(gru3)
Q_t3= Dense(100, activation="relu")(input3_final)
K_t3= Dense(100, activation="relu")(input3_final)
V_t3= Dense(100, activation="relu")(input3_final)
C3 = Lambda(attentionScoresIA)([Q_t3,K_t3,V_t3])
C3_flatten = Flatten()(C3)
emotion_specific_output = Dense(6, activation = "softmax", name = "emotion_specific_output")(C3_flatten)

"""The shared layer"""
M = Average()([C1, C2, C3])
shared_output = Dense(100, activation = "relu", name = "shared_layer")(M)
shared_output = Flatten()(shared_output)

complaint_shared_output = Dense(2, activation = "softmax", name = "task_shared_complaint")(shared_output)
sentiment_shared_output = Dense(3, activation = "softmax", name = "task_shared_sentiment")(shared_output)
emotion_shared_output = Dense(6, activation = "softmax", name = "task_shared_emotion")(shared_output)

"""Adversarial component"""
adv_complaint = GradReverse()(complaint_shared_output)
adv_sentiment = GradReverse()(sentiment_shared_output)
adv_emotion = GradReverse()(emotion_shared_output)

complaint_adv_output = Dense(2, activation="softmax", name = "task_adv_complaint")(concatenate([complaint_shared_output, adv_complaint, complaint_specific_output]))
complaint_adv_output = 1 - complaint_adv_output
sentiment_adv_output = Dense(3, activation = "softmax", name = "task_adv_sentiment")(concatenate([sentiment_shared_output, adv_sentiment, sentiment_specific_output]))
sentiment_adv_output = 1 - sentiment_adv_output
emotion_adv_output = Dense(6, activation = "softmax", name = "task_adv_emotion")(concatenate([emotion_shared_output, adv_emotion, emotion_specific_output]))
emotion_adv_output = 1 - emotion_adv_output

"""Final Output Layers"""
out_complaint = Average(name='out_complaint')([complaint_specific_output, complaint_shared_output, complaint_adv_output])
out_sentiment = Average(name='out_sentiment')([sentiment_specific_output, sentiment_shared_output, sentiment_adv_output])
out_emotion = Average(name='out_emotion')([emotion_specific_output, emotion_shared_output, emotion_adv_output])


model = Model([[input_word_ids1, input_mask1, segment_ids1],[input_word_ids2, input_mask2, segment_ids2], [input_word_ids3, input_mask3, segment_ids3]],
              [out_complaint, out_sentiment, out_emotion])

model.compile(optimizer = Adam(0.0001), loss = {'out_complaint':'categorical_crossentropy', 
                                                'out_sentiment':'categorical_crossentropy', 
                                                'out_emotion':'categorical_crossentropy'},
              loss_weights = [1, 0.5, 0.5], metrics=['accuracy'])     

earlystopping = EarlyStopping(monitor='val_out_complaint_accuracy', patience=5, verbose=1, restore_best_weights=True)

model.fit([data_train, data_sentiment_train, data_emotion_train], [complaint_labels_train, sentiment_labels_train, emotion_labels_train], 
          validation_data = ([data_val, data_sentiment_val, data_emotion_val], [complaint_labels_val, sentiment_labels_val, emotion_labels_val]), 
          batch_size = 16, shuffle=True, verbose=1, epochs = 30, callbacks=earlystopping)

# Generating Predictions #
predicted = model.predict([data_test, data_sentiment_test, data_emotion_test])
# Complaint Results #
a = predicted[0]
pred_test1 = np.argmax(a, axis=1)
classes_test1 = np.argmax(to_categorical(complaint_labels_test), axis=1)[:,1]
predictions_test1=np.array(list(pred_test1))
print(classification_report(classes_test1, predictions_test1))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test1, predictions_test1, average='macro'))
cm1 = confusion_matrix(classes_test1, predictions_test1)
print('\nConfusion matrix:\n', cm1)
print('\nAccuracy:\n',accuracy_score(classes_test1, predictions_test1))
# Sentiment Results #
b = predicted[1]
pred_test2 = np.argmax(b, axis=1)
classes_test2 = np.argmax(to_categorical(sentiment_labels_test), axis=1)[:,1]
predictions_test2=np.array(list(pred_test2))
print(classification_report(classes_test2, predictions_test2))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test2, predictions_test2, average='macro'))
cm2 = confusion_matrix(classes_test2, predictions_test2)
print('\nConfusion matrix:\n', cm2)
print('\nAccuracy:\n',accuracy_score(classes_test2, predictions_test2))
# Emotion Results #
c = predicted[2]
pred_test3 = np.argmax(c, axis=1)
classes_test3 = np.argmax(to_categorical(emotion_labels_test), axis=1)[:,1]
predictions_test3=np.array(list(pred_test3))
print(classification_report(classes_test3, predictions_test3))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test3, predictions_test3, average='macro'))
cm3 = confusion_matrix(classes_test3, predictions_test3)
print('\nConfusion matrix:\n', cm3)
print('\nAccuracy:\n',accuracy_score(classes_test3, predictions_test3))

file_name = 'Complaint Sentiment Emotion.txt'
with open(file_name, 'w') as file:
    print('Complaint Metrics\n', file=file)
    print(classification_report(classes_test1, predictions_test1), file = file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test1, predictions_test1, average='macro'), file = file)
    print('\nConfusion matrix:\n', cm1, file = file)
    print('\nAccuracy:\n',accuracy_score(classes_test1, predictions_test1), file = file)
    
    print('\nSentiment Metrics\n', file=file)
    print(classification_report(classes_test2, predictions_test2), file=file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test2, predictions_test2, average='macro'), file=file)
    print('\nConfusion matrix:\n', cm2, file=file)
    print('\nAccuracy:\n',accuracy_score(classes_test2, predictions_test2), file=file)
    
    print('\nEmotion Metrics\n', file=file)
    print(classification_report(classes_test3, predictions_test3), file =file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test3, predictions_test3, average='macro'), file = file)
    print('\nConfusion matrix:\n', cm3, file= file)
    print('\nAccuracy:\n',accuracy_score(classes_test3, predictions_test3), file = file)


"""*****************************************************************************************************************************"""


# TRAINING COMPLAINT, SARCASM, AND SENTIMENT #

"""The private layers"""
input_word_ids1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output1, sequence_output1 = bert_layer([input_word_ids1, input_mask1, segment_ids1])
gru = Bidirectional(GRU(256, name = 'gru_input_1', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output1)
input1_final = Dense(100, activation = "relu")(gru)
Q_t= Dense(100, activation="relu")(input1_final)
K_t= Dense(100, activation="relu")(input1_final)
V_t= Dense(100, activation="relu")(input1_final)
C1 = Lambda(attentionScoresIA)([Q_t,K_t,V_t])
C1_flatten = Flatten()(C1)

complaint_specific_output = Dense(2, activation = "softmax", name = "complaint_specific_output")(C1_flatten)

input_word_ids2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output2, sequence_output2 = bert_layer([input_word_ids2, input_mask2, segment_ids2])
gru2 = Bidirectional(GRU(256, name = 'gru_input_2', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output2)
input2_final = Dense(100, activation = "relu")(gru2)
Q_t2= Dense(100, activation="relu")(input2_final)
K_t2= Dense(100, activation="relu")(input2_final)
V_t2= Dense(100, activation="relu")(input2_final)
C2 = Lambda(attentionScoresIA)([Q_t2,K_t2,V_t2])
C2_flatten = Flatten()(C2)

sarcasm_specific_output = Dense(2, activation = "softmax", name = "sarcasm_specific_output")(C2_flatten)

input_word_ids3 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask3 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids3 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output3, sequence_output3 = bert_layer([input_word_ids3, input_mask3, segment_ids3])
gru3 = Bidirectional(GRU(256, name = 'gru_input_3', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output3)
input3_final = Dense(100, activation = "relu")(gru3)
Q_t3= Dense(100, activation="relu")(input3_final)
K_t3= Dense(100, activation="relu")(input3_final)
V_t3= Dense(100, activation="relu")(input3_final)
C3 = Lambda(attentionScoresIA)([Q_t3,K_t3,V_t3])
C3_flatten = Flatten()(C3)
sentiment_specific_output = Dense(3, activation = "softmax", name = "sentiment_specific_output")(C3_flatten)

"""The shared layer"""
M = Average()([C1, C2, C3])
shared_output = Dense(100, activation = "relu", name = "shared_layer")(M)
shared_output = Flatten()(shared_output)

complaint_shared_output = Dense(2, activation = "softmax", name = "task_shared_complaint")(shared_output)
sarcasm_shared_output = Dense(2, activation = "softmax", name = "task_shared_sarcasm")(shared_output)
sentiment_shared_output = Dense(3, activation = "softmax", name = "task_shared_sentiment")(shared_output)

"""Adversarial component"""
adv_complaint = GradReverse()(complaint_shared_output)
adv_sarcasm = GradReverse()(sarcasm_shared_output)
adv_sentiment = GradReverse()(sentiment_shared_output)

complaint_adv_output = Dense(2, activation="softmax", name = "task_adv_complaint")(concatenate([complaint_shared_output, adv_complaint, complaint_specific_output]))
complaint_adv_output = 1 - complaint_adv_output
sarcasm_adv_output = Dense(2, activation = "softmax", name = "task_adv_sarcasm")(concatenate([sarcasm_shared_output, adv_sarcasm, sarcasm_specific_output]))
sarcasm_adv_output = 1 - sarcasm_adv_output
sentiment_adv_output = Dense(3, activation = "softmax", name = "task_adv_sentiment")(concatenate([sentiment_shared_output, adv_sentiment, sentiment_specific_output]))
sentiment_adv_output = 1 - sentiment_adv_output

"""Final Output Layers"""
out_complaint = Average(name='out_complaint')([complaint_specific_output, complaint_shared_output, complaint_adv_output])
out_sarcasm = Average(name='out_sarcasm')([sarcasm_specific_output, sarcasm_shared_output, sarcasm_adv_output])
out_sentiment = Average(name='out_sentiment')([sentiment_specific_output, sentiment_shared_output, sentiment_adv_output])

model = Model([[input_word_ids1, input_mask1, segment_ids1],[input_word_ids2, input_mask2, segment_ids2], [input_word_ids3, input_mask3, segment_ids3]],
              [out_complaint, out_sarcasm, out_sentiment])

model.compile(optimizer = Adam(0.0001), loss = {'out_complaint':'categorical_crossentropy',
                                                'out_sarcasm': 'categorical_crossentropy',
                                                'out_sentiment':'categorical_crossentropy'},
              loss_weights=[1, 0.5, 0.5] ,metrics=['accuracy'])   

earlystopping = EarlyStopping(monitor='val_out_complaint_accuracy', patience=5, verbose=1, restore_best_weights=True)

model.fit([data_train, data_sarcasm_train, data_sentiment_train], [complaint_labels_train, sarcasm_labels_train, sentiment_labels_train], 
          validation_data = ([data_val, data_sarcasm_val, data_sentiment_val], [complaint_labels_val, sarcasm_labels_val, sentiment_labels_val]), 
          batch_size = 16, shuffle=True, verbose=1, epochs = 30, callbacks=earlystopping)

# Generating Predictions #
predicted = model.predict([data_test, data_sarcasm_test, data_sentiment_test])

# Complaint Results #
a = predicted[0]
pred_test1 = np.argmax(a, axis=1)
classes_test1 = np.argmax(to_categorical(complaint_labels_test), axis=1)[:,1]
predictions_test1=np.array(list(pred_test1))
print(classification_report(classes_test1, predictions_test1))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test1, predictions_test1, average='macro'))
cm1 = confusion_matrix(classes_test1, predictions_test1)
print('\nConfusion matrix:\n', cm1)
print('\nAccuracy:\n',accuracy_score(classes_test1, predictions_test1))
# Sarcasm Results #
b = predicted[1]
pred_test2 = np.argmax(b, axis=1)
classes_test2 = np.argmax(to_categorical(sarcasm_labels_test), axis=1)[:,1]
predictions_test2=np.array(list(pred_test2))
print(classification_report(classes_test2, predictions_test2))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test2, predictions_test2, average='macro'))
cm2 = confusion_matrix(classes_test2, predictions_test2)
print('\nConfusion matrix:\n', cm2)
print('\nAccuracy:\n',accuracy_score(classes_test2, predictions_test2))
# Sentiment Results #
c = predicted[2]
pred_test3 = np.argmax(c, axis=1)
classes_test3 = np.argmax(to_categorical(sentiment_labels_test), axis=1)[:,1]
predictions_test3=np.array(list(pred_test3))
print(classification_report(classes_test3, predictions_test3))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test3, predictions_test3, average='macro'))
cm3 = confusion_matrix(classes_test3, predictions_test3)
print('\nConfusion matrix:\n', cm3)
print('\nAccuracy:\n',accuracy_score(classes_test3, predictions_test3))

file_name = 'Complaint Sarcasm Sentiment.txt'
with open(file_name, 'w') as file:
    print('Complaint Metrics\n', file=file)
    print(classification_report(classes_test1, predictions_test1), file = file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test1, predictions_test1, average='macro'), file = file)
    print('\nConfusion matrix:\n', cm1, file = file)
    print('\nAccuracy:\n',accuracy_score(classes_test1, predictions_test1), file = file)
    
    print('\nSarcasm Metrics\n', file=file)
    print(classification_report(classes_test2, predictions_test2), file=file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test2, predictions_test2, average='macro'), file=file)
    print('\nConfusion matrix:\n', cm2, file=file)
    print('\nAccuracy:\n',accuracy_score(classes_test2, predictions_test2), file=file)
    
    print('\nSentiment Metrics\n', file=file)
    print(classification_report(classes_test3, predictions_test3), file =file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test3, predictions_test3, average='macro'), file = file)
    print('\nConfusion matrix:\n', cm3, file= file)
    print('\nAccuracy:\n',accuracy_score(classes_test3, predictions_test3), file = file)


"""*****************************************************************************************************************************"""


# TRAINING COMPLAINT, SARCASM, AND EMOTION #

"""The private layers"""
input_word_ids1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids1 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output1, sequence_output1 = bert_layer([input_word_ids1, input_mask1, segment_ids1])
gru = Bidirectional(GRU(256, name = 'gru_input_1', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output1)
input1_final = Dense(100, activation = "relu")(gru)
Q_t= Dense(100, activation="relu")(input1_final)
K_t= Dense(100, activation="relu")(input1_final)
V_t= Dense(100, activation="relu")(input1_final)
C1 = Lambda(attentionScoresIA)([Q_t,K_t,V_t])
C1_flatten = Flatten()(C1)
complaint_specific_output = Dense(2, activation = "softmax", name = "complaint_specific_output")(C1_flatten)

input_word_ids2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids2 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output2, sequence_output2 = bert_layer([input_word_ids2, input_mask2, segment_ids2])
gru2 = Bidirectional(GRU(256, name = 'gru_input_2', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output2)
input2_final = Dense(100, activation = "relu")(gru2)
Q_t2= Dense(100, activation="relu")(input2_final)
K_t2= Dense(100, activation="relu")(input2_final)
V_t2= Dense(100, activation="relu")(input2_final)
C2 = Lambda(attentionScoresIA)([Q_t2,K_t2,V_t2])
C2_flatten = Flatten()(C2)
sarcasm_specific_output = Dense(2, activation = "softmax", name = "sarcasm_specific_output")(C2_flatten)

input_word_ids3 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
input_mask3 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
segment_ids3 = Input(shape = (MAX_SENT_LENGTH, ), dtype='int32')
pooled_output3, sequence_output3 = bert_layer([input_word_ids3, input_mask3, segment_ids3])
gru3 = Bidirectional(GRU(256, name = 'gru_input_3', activation = 'tanh', dropout = 0.2, return_sequences=True))(sequence_output3)
input3_final = Dense(100, activation = "relu")(gru3)
Q_t3= Dense(100, activation="relu")(input3_final)
K_t3= Dense(100, activation="relu")(input3_final)
V_t3= Dense(100, activation="relu")(input3_final)
C3 = Lambda(attentionScoresIA)([Q_t3,K_t3,V_t3])
C3_flatten = Flatten()(C3)
emotion_specific_output = Dense(6, activation = "softmax", name = "emotion_specific_output")(C3_flatten)

"""The shared layer"""
M = Average()([C1, C2, C3])
shared_output = Dense(100, activation = "relu", name = "shared_layer")(M)
shared_output = Flatten()(shared_output)

complaint_shared_output = Dense(2, activation = "softmax", name = "task_shared_complaint")(shared_output)
sarcasm_shared_output = Dense(2, activation = "softmax", name = "task_shared_sarcasm")(shared_output)
emotion_shared_output = Dense(6, activation = "softmax", name = "task_shared_emotion")(shared_output)

"""Adversarial component"""
adv_complaint = GradReverse()(complaint_shared_output)
adv_sarcasm = GradReverse()(sarcasm_shared_output)
adv_emotion = GradReverse()(emotion_shared_output)

complaint_adv_output = Dense(2, activation="softmax", name = "task_adv_complaint")(concatenate([complaint_shared_output, adv_complaint, complaint_specific_output]))
complaint_adv_output = 1 - complaint_adv_output
sarcasm_adv_output = Dense(2, activation = "softmax", name = "task_adv_sarcasm")(concatenate([sarcasm_shared_output, adv_sarcasm, sarcasm_specific_output]))
sarcasm_adv_output = 1 - sarcasm_adv_output
emotion_adv_output = Dense(6, activation = "softmax", name = "task_adv_emotion")(concatenate([emotion_shared_output, adv_emotion, emotion_specific_output]))
emotion_adv_output = 1 - emotion_adv_output

"""Final Output Layers"""
out_complaint = Average(name='out_complaint')([complaint_specific_output, complaint_shared_output, complaint_adv_output])
out_sarcasm = Average(name='out_sarcasm')([sarcasm_specific_output, sarcasm_shared_output, sarcasm_adv_output])
out_emotion = Average(name='out_emotion')([emotion_specific_output, emotion_shared_output, emotion_adv_output])

model = Model([[input_word_ids1, input_mask1, segment_ids1],[input_word_ids2, input_mask2, segment_ids2], [input_word_ids3, input_mask3, segment_ids3]],
              [out_complaint, out_sarcasm, out_emotion])

model2.compile(optimizer = Adam(0.0001), loss = {'out_complaint':'categorical_crossentropy',
                                                'out_sarcasm': 'categorical_crossentropy',
                                                'out_emotion':'categorical_crossentropy'},
               loss_weights=[1,0.5,0.5], metrics=['accuracy'])    

earlystopping = EarlyStopping(monitor='val_out_complaint_accuracy', patience=5, verbose=1, restore_best_weights=True)

model.fit([data_train, data_sarcasm_train, data_emotion_train], [complaint_labels_train, sarcasm_labels_train, emotion_labels_train], 
          validation_data = ([data_val, data_sarcasm_val, data_emotion_val], [complaint_labels_val, sarcasm_labels_val, emotion_labels_val]), 
          batch_size = 16, shuffle=True, verbose=1, epochs = 30, callbacks=earlystopping)

# Generating Predictions #
predicted = model.predict([data_test, data_sarcasm_test, data_emotion_test])
# Complaint Results #
a = predicted[0]
pred_test1 = np.argmax(a, axis=1)
classes_test1 = np.argmax(to_categorical(complaint_labels_test), axis=1)[:,1]
predictions_test1=np.array(list(pred_test1))
print(classification_report(classes_test1, predictions_test1))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test1, predictions_test1, average='macro'))
cm1 = confusion_matrix(classes_test1, predictions_test1)
print('\nConfusion matrix:\n', cm1)
print('\nAccuracy:\n',accuracy_score(classes_test1, predictions_test1))
# Sarcasm Results #
b = predicted[1]
pred_test2 = np.argmax(b, axis=1)
classes_test2 = np.argmax(to_categorical(sarcasm_labels_test), axis=1)[:,1]
predictions_test2=np.array(list(pred_test2))
print(classification_report(classes_test2, predictions_test2))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test2, predictions_test2, average='macro'))
cm2 = confusion_matrix(classes_test2, predictions_test2)
print('\nConfusion matrix:\n', cm2)
print('\nAccuracy:\n',accuracy_score(classes_test2, predictions_test2))
# Emotion Results #
c = predicted[2]
pred_test3 = np.argmax(c, axis=1)
classes_test3 = np.argmax(to_categorical(emotion_labels_test), axis=1)[:,1]
predictions_test3=np.array(list(pred_test3))
print(classification_report(classes_test3, predictions_test3))
print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test3, predictions_test3, average='macro'))
cm3 = confusion_matrix(classes_test3, predictions_test3)
print('\nConfusion matrix:\n', cm3)
print('\nAccuracy:\n',accuracy_score(classes_test3, predictions_test3))

file_name = 'Complaint Sarcasm Emotion.txt'
with open(file_name, 'w') as file:
    print('Complaint Metrics\n', file=file)
    print(classification_report(classes_test1, predictions_test1), file = file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test1, predictions_test1, average='macro'), file = file)
    print('\nConfusion matrix:\n', cm1, file = file)
    print('\nAccuracy:\n',accuracy_score(classes_test1, predictions_test1), file = file)
    
    print('\nSarcasm Metrics\n', file=file)
    print(classification_report(classes_test2, predictions_test2), file=file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test2, predictions_test2, average='macro'), file=file)
    print('\nConfusion matrix:\n', cm2, file=file)
    print('\nAccuracy:\n',accuracy_score(classes_test2, predictions_test2), file=file)
    
    print('\nEmotion Metrics\n', file=file)
    print(classification_report(classes_test3, predictions_test3), file =file)
    print('Precision - Recall - F1 score:\n',precision_recall_fscore_support(classes_test3, predictions_test3, average='macro'), file = file)
    print('\nConfusion matrix:\n', cm3, file= file)
    print('\nAccuracy:\n',accuracy_score(classes_test3, predictions_test3), file = file)
